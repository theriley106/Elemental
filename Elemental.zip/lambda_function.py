import alexaHelper
import random
import re
import json

ELEMENTLIST = json.load(open('elements.json'))["elements"]

SKILLNAME = "Elemental"
INITIALSPEECH = "Thanks for checking out Elemental!  You can ask me to quiz you on Periodic Table elements"
REPEATSPEECH = "Start by asking, start a quiz"

def lambda_handler(event, context):
	appID = event['session']['application']['applicationId']
	print str(event)
	if event["request"]["type"] == "LaunchRequest":
		return alexaHelper.get_welcome_response(SKILLNAME, INITIALSPEECH, REPEATSPEECH)
	elif event["request"]["type"] == "IntentRequest":
		return on_intent(event["request"], event["session"])

def on_intent(intent_request, session):
	intent = intent_request["intent"]
	intent_name = intent_request["intent"]["name"]
	if intent_name == 'quizMe':
		element = random.choice(ELEMENTLIST)
		print element
		print element['name']
		print element['symbol']
	elif intent_name == 'aboutDev':
		return alexaHelper.devInfo()
	elif intent_name == "AMAZON.HelpIntent":
		return alexaHelper.get_help_response(REPEATSPEECH)
	elif intent_name == "AMAZON.CancelIntent" or intent_name == "AMAZON.StopIntent":
		return alexaHelper.handle_session_end_request()